# Como subir a rifa

## Site leve

Suba apenas os arquivos da pasta `dist-site` na hospedagem comum:

- `index.html`
- `styles.css`
- `app.js`
- `qrcode.min.js`

Nao suba `node_modules`, `.env`, `.git`, `package-lock.json` ou arquivos de desenvolvimento.

## Pix Mercado Pago

O Pix precisa do backend Node em `server.js`. Hospedagem estatica comum nao roda essa API.

Se o backend ficar em outro dominio, edite no `index.html`:

```html
window.RIFA_API_BASE_URL = 'https://seu-backend.com';
```

Se site e backend estiverem no mesmo dominio, deixe vazio:

```html
window.RIFA_API_BASE_URL = '';
```

## Backend

No host Node, envie:

- `server.js`
- `package.json`
- `package-lock.json`
- `scripts/`

Configure as variaveis de ambiente do host usando os mesmos nomes do `.env.example`.
